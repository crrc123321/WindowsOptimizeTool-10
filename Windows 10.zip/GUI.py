import sys,OptimizeWindows,GetWindowsVersion,icon
from PySide6.QtCore import QThread, Signal, Qt
from PySide6.QtWidgets import QApplication, QMainWindow, QPushButton, QVBoxLayout, QWidget, QMessageBox, QGroupBox, QGridLayout
from PySide6.QtGui import QIcon
from OptimizeWindows import WindowsVersionError

class OptimizationWorker(QThread):
    Finished = Signal(str)
    Error = Signal(str, str)
    WindowsUpdate = Signal(str)
    WindowsDefender = Signal(str)

    def __init__(self, OptimizeBehavior):
        super().__init__()
        self.OptimizeBehavior = OptimizeBehavior

    def run(self):
        try:
            # Windows更新
            if self.OptimizeBehavior == "disableWindowsUpdate":
                OptimizeWindows.disableWindowsUpdate()
                self.WindowsUpdate.emit(self.OptimizeBehavior)
            # 保留存储相关
            elif self.OptimizeBehavior == "enablePreservedStorage":
                OptimizeWindows.enablePreservedStorage()
                self.Finished.emit(self.OptimizeBehavior)
            elif self.OptimizeBehavior == "disablePreservedStorage":
                OptimizeWindows.disablePreservedStorage()
                self.Finished.emit(self.OptimizeBehavior)
            # 休眠相关
            elif self.OptimizeBehavior == "enableHibernate":
                OptimizeWindows.enableHibernate()
                self.Finished.emit(self.OptimizeBehavior)
            elif self.OptimizeBehavior == "disableHibernate":
                OptimizeWindows.disableHibernate()
                self.Finished.emit(self.OptimizeBehavior)
            # 卸载OneDrive
            elif self.OptimizeBehavior == "uninstallTheFuckOneDrive":
                OptimizeWindows.uninstallTheFuckOneDrive()
                self.Finished.emit(self.OptimizeBehavior)
            # 组策略
            elif self.OptimizeBehavior == "killTheFuckGroupPolicy":
                OptimizeWindows.killTheFuckGroupPolicy()
                self.Finished.emit(self.OptimizeBehavior)
            # 计划任务
            elif self.OptimizeBehavior == "cleanTheFuckScheduleTask":
                OptimizeWindows.cleanTheFuckScheduleTask()
                self.Finished.emit(self.OptimizeBehavior)
            # 注册表
            elif self.OptimizeBehavior == "cleanTheFuckReg":
                OptimizeWindows.cleanTheFuckReg()
                self.Finished.emit(self.OptimizeBehavior)
            # 清除Appx
            elif self.OptimizeBehavior == "deleteTheFuckAppx":
                OptimizeWindows.deleteTheFuckAppx()
                self.Finished.emit(self.OptimizeBehavior)
            # 移除无用功能
            elif self.OptimizeBehavior == "removeTheUselessFeature":
                OptimizeWindows.removeTheUselessFeature()
                self.Finished.emit(self.OptimizeBehavior)
            # 添加NET3.5
            elif self.OptimizeBehavior == "addNet35":
                OptimizeWindows.addNet35()
                self.Finished.emit(self.OptimizeBehavior)
            # 停用Windows Defender
            elif self.OptimizeBehavior == "disableTheFuckDefender":
                OptimizeWindows.disableTheFuckDefender()
                self.WindowsDefender.emit(self.OptimizeBehavior)
        except Exception as e:
            self.Error.emit("执行失败", f"发生了未知错误：\n{str(e)}")

class MainWindow(QMainWindow):
    def __init__(self):
        # 判断当前系统到底是不是Windows 10，不然总有刁民想在其他系统上跑，崩了咋办？
        if 'Windows 10' not in GetWindowsVersion.getWinVer():
            raise WindowsVersionError("你的系统是Windows 10吗？\n如果不是，请下载Windows 11专版，否则可能会出现无法预料的问题")

        super().__init__()
        self.setWindowTitle("Windows 优化工具")
        self.setMinimumSize(440, 320)
        icon = QIcon(":/icons/Windows10.png")
        self.setWindowIcon(icon)

        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)
        self.main_layout = QVBoxLayout(self.central_widget)

        self.content_layout = QGridLayout()
        self.main_layout.addLayout(self.content_layout)

        # 记录每个按钮的原始文本，用于后续恢复
        self.original_texts = {}

        self.hibGroup()
        self.preservedStorageGroup()
        self.otherGroup()

    def hibGroup(self):
        group = QGroupBox("休眠设置")
        group.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        layout = QVBoxLayout(group)
        # 按钮
        self.SleepOnButton = QPushButton("开启")
        self.SleepOffButton = QPushButton("关闭")
        # 设置按钮点击行为
        self.SleepOnButton.clicked.connect(lambda: self.startAction(self.SleepOnButton, "enableHibernate"))
        self.SleepOffButton.clicked.connect(lambda: self.startAction(self.SleepOffButton, "disableHibernate"))
        # 把按钮添加到界面上去
        layout.addWidget(self.SleepOnButton)
        layout.addWidget(self.SleepOffButton)
        self.content_layout.addWidget(group, 0, 0)

    def preservedStorageGroup(self):
        group = QGroupBox("保留的存储")
        group.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        layout = QVBoxLayout(group)
        # 按钮
        self.EnableStorageButton = QPushButton("开启")
        self.DisableStorageButton = QPushButton("关闭")
        # 设置按钮点击行为
        self.EnableStorageButton.clicked.connect(lambda: self.startAction(self.EnableStorageButton, "enablePreservedStorage"))
        self.DisableStorageButton.clicked.connect(lambda: self.startAction(self.DisableStorageButton, "disablePreservedStorage"))
        # 把按钮添加到界面上去
        layout.addWidget(self.EnableStorageButton)
        layout.addWidget(self.DisableStorageButton)
        self.content_layout.addWidget(group, 1, 0)

    def otherGroup(self):
        group = QGroupBox("其他优化")
        group.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        layout = QVBoxLayout(group)
        # 按钮
        self.DisableUpdateButton = QPushButton("停用 Windows 更新10年")
        self.UninstallOneDriveButton = QPushButton("卸载 OneDrive")
        self.RemoveGroupPolicyButton = QPushButton("修改不合理的组策略")
        self.DisableTasksButton = QPushButton("禁用不合理的计划任务")
        self.CleanTheFuckRegButton = QPushButton("优化注册表")
        self.CleanAppxButton = QPushButton("清理无用 Appx")
        self.RemoveFeatureButton = QPushButton("移除无用功能")
        self.AddNet35Button = QPushButton("添加.NET 3.5")
        self.DisableDefenderButton = QPushButton("停用Windows Defender(建议搭配NSudo)")
        # 设置按钮点击行为
        self.DisableUpdateButton.clicked.connect(lambda: self.startAction(self.DisableUpdateButton, "disableWindowsUpdate"))
        self.UninstallOneDriveButton.clicked.connect(lambda: self.startAction(self.UninstallOneDriveButton, "uninstallTheFuckOneDrive"))
        self.RemoveGroupPolicyButton.clicked.connect(lambda: self.startAction(self.RemoveGroupPolicyButton, "killTheFuckGroupPolicy"))
        self.DisableTasksButton.clicked.connect(lambda: self.startAction(self.DisableTasksButton, "cleanTheFuckScheduleTask"))
        self.CleanTheFuckRegButton.clicked.connect(lambda: self.startAction(self.CleanTheFuckRegButton, "cleanTheFuckReg"))
        self.CleanAppxButton.clicked.connect(lambda: self.startAction(self.CleanAppxButton, "deleteTheFuckAppx"))
        self.RemoveFeatureButton.clicked.connect(lambda: self.startAction(self.RemoveFeatureButton, "removeTheUselessFeature"))
        self.AddNet35Button.clicked.connect(lambda: self.startAction(self.AddNet35Button, "addNet35"))
        self.DisableDefenderButton.clicked.connect(lambda: self.startAction(self.DisableDefenderButton, "disableTheFuckDefender"))
        # 把按钮添加到界面上去
        layout.addWidget(self.DisableUpdateButton)
        layout.addWidget(self.UninstallOneDriveButton)
        layout.addWidget(self.RemoveGroupPolicyButton)
        layout.addWidget(self.DisableTasksButton)
        layout.addWidget(self.CleanTheFuckRegButton)
        layout.addWidget(self.CleanAppxButton)
        layout.addWidget(self.RemoveFeatureButton)
        layout.addWidget(self.AddNet35Button)
        layout.addWidget(self.DisableDefenderButton)
        self.content_layout.addWidget(group, 0, 2, 2, 2)

    # 统一的触发器（接收当前被点击的按钮对象）
    def startAction(self, clicked_button, OptimizeBehavior):
        # 动态抓取界面所有按钮，全部变灰
        for widget in self.central_widget.findChildren(QPushButton):
            widget.setEnabled(False)
            # 把每个按钮原来的文字记下来，防止后面找不回
            self.original_texts[widget] = widget.text()
        
        # 精准定位当前被戳的按钮，改写文字
        clicked_button.setText("正在执行，请稍候")
        
        self.worker = OptimizationWorker(OptimizeBehavior)
        self.worker.Finished.connect(self.ActionSucceed)
        self.worker.Error.connect(self.ActionFailed)
        self.worker.WindowsUpdate.connect(self.WindowsUpdateHint)
        self.worker.WindowsDefender.connect(self.DefenderHint)
        self.worker.start()

    def ActionSucceed(self, OptimizeBehavior):
        self.ResetUI()
        QMessageBox.information(self, "恭喜", "执行成功")

    def DefenderHint(self, OptimizeBehavior):
        self.ResetUI()
        QMessageBox.information(None, "提示", "建议去“Windows安全中心”内，点击“病毒和威胁防护”，找到“病毒和威胁防护”设置部分，点击下方的“管理设置”，关闭所有开关，以便完全关闭\n但这样做会使计算机处于安全风险中，所以建议安装火绒来规避风险")

    def WindowsUpdateHint(self, OptimizeBehavior):
        self.ResetUI()
        QMessageBox.information(None, "提示：即将打开设置界面", "打开设置界面以后，选择“高级选项”，查看“暂停更新”部分，选择你想停止到的日期即可")
        OptimizeWindows.openWindowsSettings()

    def ActionFailed(self, title, msg):
        self.ResetUI()
        QMessageBox.critical(self, title, msg)

    def ResetUI(self):
        # 恢复所有按钮的状态和字样
        for widget in self.central_widget.findChildren(QPushButton):
            widget.setEnabled(True)
            # 从字典里把当初存的原始文字拿出来换回去
            if widget in self.original_texts:
                widget.setText(self.original_texts[widget])

if __name__ == "__main__":
    app = QApplication(sys.argv)
    try:
        window = MainWindow()
        window.show()
        sys.exit(app.exec())
    except WindowsVersionError as e:
        QMessageBox.critical(None, "系统和工具版本不匹配", str(e))
        sys.exit(0)