import winreg as reg

def getWinVer():
    try:
        with reg.OpenKey(reg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows NT\CurrentVersion", 0, reg.KEY_READ) as key:
            BuildNumberReg, _ = reg.QueryValueEx(key, "CurrentBuild")
            BuildNumber = int(BuildNumberReg)
            
            if BuildNumber < 22000:
                return "Windows 10"
            else:
                return "Windows 11"

    except Exception:
        # 如果读取失败，保守起见返回 False，防止未知错误
        return False