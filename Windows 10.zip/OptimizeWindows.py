import os

class WindowsVersionError(Exception):
    pass

# 占位的
def openWindowsSettings():
        os.system('start ms-settings:windowsupdate')

# 去你奶奶的Windows更新，10年后见吧
def disableWindowsUpdate():
    os.system('reg add "HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\WindowsUpdate\\UX\\Settings" /v "FlightSettingsMaxPauseDays" /t REG_DWORD /d 3650 /f')

# 保留存储相关
def disablePreservedStorage():
    os.system('DISM.exe /Online /Set-ReservedStorageState /State:Disabled')
def enablePreservedStorage():
    os.system('DISM.exe /Online /Set-ReservedStorageState /State:Enabled')

# 休眠相关
def disableHibernate():
    os.system('powercfg /h off')
def enableHibernate():
    os.system('powercfg /h on')

# 卸载万年用不到的sOneDrive
def uninstallTheFuckOneDrive():
    Commands = ['taskkill /f /im OneDrive.exe && %SystemRoot%\\SysWOW64\\OneDriveSetup.exe /uninstall','del /f /s /q %SystemRoot%\\SysWOW64\\OneDriveSetup.exe']
    for Command in Commands:
        os.system(Command)

# 停用那要命的Windows Defender
def disableTheFuckDefender():
    Commands = ['sc stop WinDefend','sc stop WerSvc','sc config WinDefend start= disabled','sc config WerSvc start= disabled']
    for Command in Commands:
        os.system(Command)

# 干死不合理的组策略
def killTheFuckGroupPolicy():
    Commands = ['sc stop WMPNetworkSvc','sc stop wsearch','sc stop DiagTrack','sc config WMPNetworkSvc start= disabled','sc config wsearch start= disabled','sc config DiagTrack start= disabled']
    for Command in Commands:
        os.system(Command)

# 清理掉万年用不到的计划任务
def cleanTheFuckScheduleTask():
    # 微软系统诊断与错误上报
    os.system(r'SCHTASKS /Change /DISABLE /TN "\Microsoft\Windows\Windows Error Reporting\QueueReporting"')
    os.system(r'SCHTASKS /Change /DISABLE /TN "\Microsoft\Windows\DiskDiagnostic\Microsoft-Windows-DiskDiagnosticResolver"')
    os.system(r'SCHTASKS /Change /DISABLE /TN "\Microsoft\Windows\DiskDiagnostic\Microsoft-Windows-DiskDiagnosticDataCollector"')
    os.system(r'SCHTASKS /Change /DISABLE /TN "\Microsoft\Windows\Diagnosis\Scheduled"')
    # SkyDrive/OneDrive 残留同步任务
    os.system(r'SCHTASKS /Change /DISABLE /TN "\Microsoft\Windows\SkyDrive\Routine Maintenance Task"')
    os.system(r'SCHTASKS /Change /DISABLE /TN "\Microsoft\Windows\SkyDrive\Idle Sync Maintenance Task"')
    # 谷歌与 Adobe 第三方更新工具
    os.system(r'SCHTASKS /Change /DISABLE /TN "\GoogleUpdateTaskMachineUA"')
    os.system(r'SCHTASKS /Change /DISABLE /TN "\GoogleUpdateTaskMachineCore"')
    os.system(r'SCHTASKS /Change /DISABLE /TN "\AdobeAAMUpdater-1.0-%computername%-%username%"')
    # Office 遥测与订阅检查
    os.system(r'SCHTASKS /Change /DISABLE /TN "\Microsoft\Office\OfficeTelemetryAgentFallBack"')
    os.system(r'SCHTASKS /Change /DISABLE /TN "\Microsoft\Office\OfficeTelemetryAgentLogOn"')
    os.system(r'SCHTASKS /Change /DISABLE /TN "\Microsoft\Office\Office 15 Subscription Heartbeat"')

# 清理一些垃圾注册表
def cleanTheFuckReg():
    # 使用 & 将所有命令连成一条。为了防止某条命令执行失败阻断后续命令，使用 & 而不是 &&
    # 每一行末尾加一个空格和续行符 \ 拼接成单条长命令
    command = (
        'reg add "HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\ContentDeliveryManager" /v "SubscribedContent-338388Enabled" /t REG_DWORD /d 0 /f & '
        'reg add "HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\ContentDeliveryManager" /v "SilentInstalledAppsEnabled" /t REG_DWORD /d 0 /f & '
        'reg add "HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\ContentDeliveryManager" /v "RotatingLockScreenOverlayEnabled" /t REG_DWORD /d 0 /f & '
        'reg add "HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\ContentDeliveryManager" /v "SubscribedContent-338387Enabled" /t REG_DWORD /d 0 /f & '
        'reg add "HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\ContentDeliveryManager" /v "SubscribedContent-338389Enabled" /t REG_DWORD /d 0 /f & '
        'reg add "HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\CloudContent" /v "DisableWindowsConsumerFeatures" /t REG_DWORD /d 1 /f & '
        'reg add "HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced" /v "Start_NotifyNewApps" /t REG_DWORD /d 0 /f & '
        'reg add "HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Search" /v "AllowCortana" /t REG_DWORD /d 0 /f & '
        'reg add "HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows Defender" /v "DisableAntiSpyware" /d 1 /t REG_DWORD /f & '
        'reg add "HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer" /v "SmartScreenEnabled" /d off /t REG_SZ /f & '
        'reg add "HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Error Reporting" /v "Disabled" /d 1 /t REG_DWORD /f & '
        'reg add "HKEY_CURRENT_USER\\Software\\Policies\\Microsoft\\Windows\\Windows Error Reporting" /v "LoggingDisabled" /d 1 /t REG_DWORD /f & '
        'reg add "HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\SQMClient\\Windows" /v "CEIPEnable" /d 0 /t REG_DWORD /f & '
        'reg add "HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control" /v "WaitToKillServiceTimeout" /d 2000 /t REG_SZ /f & '
        'reg add "HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced" /v "HideFileExt" /t REG_DWORD /d 0 /f & '
        'reg add "HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced" /v "LaunchTo" /t REG_DWORD /d 2 /f & '
        'reg add "HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Shell Icons" /v "29" /t REG_SZ /d "%systemroot%\\system32\\imageres.dll,197" /f & '
        'reg add "HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced" /v "TaskbarGlomLevel" /t REG_DWORD /d 2 /f & '
        'reg add "HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer" /v "link" /t REG_BINARY /d 00000000 /f & '
        'reg add "HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced" /v "FullPath" /t REG_DWORD /d 1 /f & '
        'reg add "HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer" /v "ShowRecent" /t REG_DWORD /d 0 /f & '
        'reg add "HKEY_CURRENT_USER\\Software\\Microsoft\\CTF\\LangBar" /v "ShowStatus" /t REG_DWORD /d 4 /f & '
        'reg delete "HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Desktop\\NameSpace\\DelegateFolders\\{F5FB2C77-0E2F-4A16-A381-3E560C68BC83}" /f >nul 2>&1 & '
        'reg add "HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer" /v "NoCDBurning" /t REG_DWORD /d 1 /f & '
        'reg add "HKEY_CURRENT_USER\\System\\GameConfigStore" /v "GameDVR_Enabled" /t REG_DWORD /d 0 /f & '
        'reg add "HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\GameDVR" /v "AllowGameDVR" /t REG_DWORD /d 0 /f & '
        'reg add "HKEY_USERS\\.DEFAULT\\Control Panel\\Keyboard" /v "InitialKeyboardIndicators" /t REG_SZ /d "2" /f & '
        'reg add "HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\HideDesktopIcons\\NewStartPanel" /v "{20D04FE0-3AEA-1069-A2D8-08002B30309D}" /d 0 /t REG_DWORD /f & '
        'reg add "HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\HideDesktopIcons\\NewStartPanel" /v "{5399e694-6ce5-4d6c-8fce-1d8870fdcba0}" /d 0 /t REG_DWORD /f & '
        'reg delete "HKEY_CLASSES_ROOT\\exefile\\shellex\\ContextMenuHandlers\\Compatibility" /f >nul 2>&1 & '
        'reg delete "HKEY_LOCAL_MACHINE\\SOFTWARE\\Classes\\SystemFileAssociations\\.jpg\\Shell\\3D Edit" /f >nul 2>&1 & '
        'reg delete "HKEY_LOCAL_MACHINE\\SOFTWARE\\Classes\\SystemFileAssociations\\.png\\Shell\\3D Edit" /f >nul 2>&1 & '
        'reg delete "HKEY_CLASSES_ROOT\\*\\shellex\\ContextMenuHandlers\\Sharing" /f >nul 2>&1 & '
        'reg delete "HKEY_CLASSES_ROOT\\Directory\\shellex\\ContextMenuHandlers\\Sharing" /f >nul 2>&1 & '
        'reg delete "HKEY_LOCAL_MACHINE\\SOFTWARE\\Classes\\Folder\\shellex\\ContextMenuHandlers\\PintoStartScreen" /f >nul 2>&1 & '
        'reg delete "HKEY_CLASSES_ROOT\\Drive\\shell\\encrypt-bde" /f >nul 2>&1 & '
        'reg delete "HKEY_CLASSES_ROOT\\Folder\\ShellEx\\ContextMenuHandlers\\PintoQuickaccess" /f >nul 2>&1 & '
        'reg delete "HKEY_CLASSES_ROOT\\AllFilesystemObjects\\shellex\\ContextMenuHandlers\\Offline Files" /f >nul 2>&1 & '
        'reg delete "HKEY_CLASSES_ROOT\\AllFilesystemObjects\\shellex\\ContextMenuHandlers\\WorkFolders" /f >nul 2>&1 & '
        'reg delete "HKEY_CLASSES_ROOT\\.contact\\ShellNew" /f >nul 2>&1 & '
        'reg delete "HKEY_CLASSES_ROOT\\*\\shellex\\ContextMenuHandlers\\EPP" /f >nul 2>&1 & '
        'reg delete "HKEY_CLASSES_ROOT\\Directory\\shellex\\ContextMenuHandlers\\EPP" /f >nul 2>&1 & '
        'reg delete "HKEY_CLASSES_ROOT\\Drive\\shellex\\ContextMenuHandlers\\EPP" /f >nul 2>&1 & '
        'reg delete "HKEY_CLASSES_ROOT\\*\\shellex\\ContextMenuHandlers\\Microsoft.Compute.System.ProjectedFileSystem" /f >nul 2>&1 & '
        'reg delete "HKEY_CLASSES_ROOT\\AllFilesystemObjects\\shellex\\ContextMenuHandlers\\{596AB062-B4D2-4215-9F74-E9109B0A8153}" /f >nul 2>&1 & '
        'reg delete "HKEY_CLASSES_ROOT\\AllFilesystemObjects\\shell\\SPFS.ContextMenu" /f >nul 2>&1 & '
        'reg delete "HKEY_CLASSES_ROOT\\Drive\\shell\\MobileDoc" /f >nul 2>&1 & '
        'reg add "HKEY_CLASSES_ROOT\\Directory\\Background\\shell\\cmd" /v "HideBasedOnVelocityId" /t REG_DWORD /d 0 /f & '
        'reg add "HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\Explorer" /v "NoUseStoreOpenWith" /t REG_DWORD /d 1 /f & '
        'reg delete "HKEY_CLASSES_ROOT\\Folder\\ShellEx\\ContextMenuHandlers\\Library Location" /f >nul 2>&1 & '
        'reg add "HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows\\HomeGroup" /v "DisableHomeGroup" /d 1 /t REG_DWORD /f & '
        'reg add "HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\PCHealth\\ErrorReporting" /v "DoReport" /d 0 /t REG_DWORD /f & '
        'reg add "HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows NT\\Terminal Services" /v "fAllowToGetHelp" /d 0 /t REG_DWORD /f & '
        'reg add "HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows NT\\Terminal Services" /v "fAllowUnsolicited" /d 0 /t REG_DWORD /f & '
        'reg add "HKEY_LOCAL_MACHINE\\SOFTWARE\\Policies\\Microsoft\\Windows NT\\Terminal Services" /v "fDenyTSConnections" /d 1 /t REG_DWORD /f & '
        'reg add "HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\CrashControl" /v "LogEvent" /d 0 /t REG_DWORD /f & '
        'reg add "HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\CrashControl" /v "AutoReboot" /d 0 /t REG_DWORD /f & '
        'reg add "HKEY_LOCAL_MACHINE\\Software\\Microsoft\\Windows\\CurrentVersion\\Component Based Servicing" /v "EnableLog" /t REG_DWORD /d 0 /f & '
        'reg add "HKEY_LOCAL_MACHINE\\Software\\Software\\Microsoft\\Windows\\CurrentVersion\\DeltaPackageExpander" /v "EnableLog" /t REG_DWORD /d 0 /f >nul 2>&1 & '
        'reg add "HKEY_LOCAL_MACHINE\\Software\\Microsoft\\Windows\\CurrentVersion\\Component Based Servicing" /v "EnableBackup" /t REG_DWORD /d 0 /f & '
        'logman stop WdiContextLog -ets >nul 2>&1 & '
        'reg add "HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\WMI\\Autologger\\WdiContextLog" /v "Start" /t REG_DWORD /d 0 /f'
    )
    
    os.system(command)

# 删除狗屎Appx
def deleteTheFuckAppx():
    Targets = [
        "BingSearch", "GetHelp", "Getstarted", "Microsoft3DViewer", "MicrosoftOfficeHub",
        "MixedReality.Portal", "Office.OneNote", "OutlookForWindows", "People", "SkypeApp",
        "Wallet", "DevHome", "windowscommunicationsapps", "WindowsFeedbackHub", "WindowsMaps",
        "Xbox.TCUI", "XboxApp", "XboxGameOverlay", "XboxGamingOverlay", "XboxSpeechToTextOverlay", "YourPhone"
    ]
    
    for target in Targets:
        os.system(f'powershell -Command "Get-AppxProvisionedPackage -Online | Where-Object {{$_.DisplayName -like \'*{target}*\'}} | Remove-AppxProvisionedPackage -Online -ErrorAction SilentlyContinue"')
        os.system(f'powershell -Command "Get-AppxPackage -AllUsers -Name \'*{target}*\' | Remove-AppxPackage -AllUsers -ErrorAction SilentlyContinue"')

# 去你大爷的没用的功能
def removeTheUselessFeature():
    Commands = r"""
    dism /online /Disable-Feature /FeatureName:Internet-Explorer-Optional-amd64 /NoRestart
    dism /online /Disable-Feature /FeatureName:Windows-Defender-Default-Definitions /NoRestart
    dism /online /Disable-Feature /FeatureName:WorkFolders-Client /NoRestart
    dism /online /Disable-Feature /FeatureName:Printing-XPSServices-Features /NoRestart
    dism /online /Disable-Feature /FeatureName:MicrosoftWindowsPowerShellV2Root /NoRestart
    dism /online /Disable-Feature /FeatureName:MicrosoftWindowsPowerShellV2 /NoRestart
    dism /online /Remove-Capability /CapabilityName:App.StepsRecorder~~~~0.0.1.0
    dism /online /Remove-Capability /CapabilityName:App.Support.QuickAssist~~~~0.0.1.0
    dism /online /Remove-Capability /CapabilityName:MathRecognizer~~~~0.0.1.0
    """
    
    # 遍历多行文本，剔除空白，逐行调用系统 cmd 执行
    for line in Commands.strip().split('\n'):
        cmd = line.strip()
        if cmd:  # 确保不是空行
            os.system(cmd)

# 给爷把.NET3.5补上
def addNet35():
    os.system('dism /online /Enable-Feature /FeatureName:NetFx3 /All /NoRestart')